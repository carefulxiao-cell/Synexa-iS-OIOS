# SIA Strong Base v0.4.0｜后台强底座

## Layer Structure

SIA runs through three layers:

1. Launch Layer｜轻启动层
   User-facing, fast, concise, output-oriented.

2. Support Layer｜支撑调用层
   Selectively invokes roles, domains, skills, and execution agents.

3. Base Layer｜强底座层
   Contains the full governance structure, role system, asset rules, test cases, and migration memory.

## Capability Domains

- iS-Core: global governance only.
- iS-SCO: strategy and decision reasoning.
- iS-Matrix: structured production and reusable assets.
- iS-Hub: external intelligence and best practice scanning.
- iS-Lab: early validation and minimum testing.
- PCS: project execution and asset destination.

## Role System

Use as role pool, not fixed organization.

### Expert Pod
Strategy, brand, product, technical, data, finance, legal/risk, visual design, UX/IA, industry research, medical/nutrition, supply chain, operations, content/editorial, education/training.

### Professional Pod
Project manager, documentation engineer, version manager, QA officer, delivery manager, knowledge base manager, executive secretary, repository manager, test lead, prompt engineer, workflow designer, training coordinator.

## Foundation Skills

- SIA: activation and alignment.
- EKB: probability and decision support.
- N-Grid: strategic reasoning and reverse validation.
- Task Room Orchestrator: planned/optional executor for SIA-Start and SIA-Work.
- Baseline Auditor: planned/optional executor for SIA-Audit.
- Release Checker: planned/optional executor for SIA-Release.

## Project / Theme Skills

Examples: Synexa Website Visual System, Synexa Visual Design Director, Nex2U Hospital Nutrition System, FineSense Content System, Verdatar Plant Archive, LiberVini Wine Advisor.

## Asset Governance Nodes

- GitHub: source, versions, releases, history.
- CONTEXT_OS: global state ledger.
- Skill Library: current installable skill version.
- SOP Library: formal procedures and templates.
- Case Log: real test cases.
- Patch Log: issue and fix history.
- File Registry: file path, status, version, ownership.
- Feishu docs/base: field collaboration materials.

## Core Use Boundary

Call Core only for global baseline changes, project placement, major resources, priority conflict, organization rules, and external commitments.

Do not call Core for ordinary copy edits, local visual choices, file names, local prompt patches, minor SOP edits, or regular meeting notes.
