# SIA Migration Notes v0.4.0

## Version Experience

### v0.1
Operational pilot. It proved that SIA can trigger modes and start Task Room logic.

### v0.2
Governance base. It built the comprehensive role/domain/skill/asset/test foundation but became too heavy for daily use.

### v0.3
Minimal runtime. It restored speed and task-command clarity but needed the strong base behind it.

### v0.4
Strong Base, Light Launch. It fuses the previous lessons: deep base, light entry, selective invocation, direct production, strict quality gate.

## Old Mechanisms

### Cross_Workspace_Collaboration_Protocol
Status: superseded / historical protocol prototype.
Retain: handoff package, return feedback, collaboration level, patch log.
Do not retain: default cross-chat transfer logic.

### synexa-collaboration-router
Status: superseded / absorbed / historical skill prototype.
Retain: trigger logic, handoff generator, runtime fallback, case log.
Do not retain: user-as-middleman routing burden.

## Replacement Rule

SIA v0.4.0 supersedes earlier SIA v0.2.0 and v0.1.0 packages as the active foundation skill.

GitHub active release directory should contain only the current active package. Previous packages move to archive and remain traceable.
