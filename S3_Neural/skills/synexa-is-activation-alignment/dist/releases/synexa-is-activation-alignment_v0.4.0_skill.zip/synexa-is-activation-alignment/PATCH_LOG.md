# PATCH_LOG

## v0.4.0

Problem: SIA had become over-engineered and slow, causing mechanism work to replace real work.

Patch: Reframed SIA as Strong Base, Light Launch. The strong base remains in references; runtime behavior becomes concise, selective, productive, and quality-gated.

Decision: v0.4.0 supersedes v0.2.0 and v0.1.0 as the active foundation skill.
