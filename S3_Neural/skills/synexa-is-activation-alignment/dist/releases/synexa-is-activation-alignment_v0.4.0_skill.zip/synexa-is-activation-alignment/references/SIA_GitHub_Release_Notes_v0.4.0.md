# SIA GitHub Release Notes v0.4.0

## Official Package

synexa-is-activation-alignment_v0.4.0_skill.zip

## Status

active / active foundation skill / ready for GPT upload

## Supersedes

- synexa-is-activation-alignment_v0.2.0_skill.zip
- synexa-is-activation-alignment_v0.1.0_skill.zip

## Directory Rule

`dist/releases/` contains only the current active release.

Older releases move to:

`archive/releases/`

Do not delete historical releases.

## Manus Instruction

Manus should upload the provided zip, not regenerate it. It should move older releases to archive, update File Registry, CHANGELOG, PATCH_LOG, and return paths.
