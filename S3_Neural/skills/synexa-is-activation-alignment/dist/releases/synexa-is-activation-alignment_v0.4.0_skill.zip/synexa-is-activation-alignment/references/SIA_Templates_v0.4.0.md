# SIA Templates v0.4.0

## Light Launch Template

```markdown
# SIA Light Launch

## 1. 任务本质

## 2. 主责归位

## 3. 本轮目标

## 4. 必要角色

## 5. 必要能力域

## 6. 直接产出

## 7. 外部执行体判断

## 8. 验收标准
```

## SIA-Lite Template

```markdown
# SIA-Lite

## 任务目标

## 任务归属

## 是否需要 Task Room

## 必要角色视角

## 必要能力域

## 下一步具体产出

## 待确认事项
```

## Full Task Room Brief

```markdown
# Mission Brief

## Goal

## Background

## Boundary

## Owner / Sponsor

## Selected Roles

## Capability Domains

## Direct Deliverables

## External Agents

## Asset Destination

## Acceptance Criteria

## Feedback Loop
```

## External Agent Task Package

```markdown
# Task Package

## Task Name

## Executor

## Goal

## Inputs

## Output

## Quality Standard

## Forbidden Actions

## Pause Conditions

## Return Format
1. What was done
2. Where the output is
3. Problems found
4. Whether it can move to the next step
```

## Quality Gate Template

```markdown
# Quality Gate

## Goal Match
Pass / Partial / Fail

## Concept Drift
None / Minor / Major

## Usability
Ready / Needs Patch / Reject

## File and Version Clarity
Clear / Partial / Missing

## Decision
Accept / Rework / Escalate

## Rework Request
```

## Manus GitHub Upload Package

```markdown
# Manus Task Package｜Upload Skill to GitHub

## Goal
Upload the provided zip package to GitHub and update repository records.

## New File
synexa-is-activation-alignment_v0.4.0_skill.zip

## Replaces / Supersedes
synexa-is-activation-alignment_v0.2.0_skill.zip
synexa-is-activation-alignment_v0.1.0_skill.zip

## Active Path
04-skills/synexa-is-activation-alignment/dist/releases/

## Archive Rule
dist/releases/ keeps only current active version.
Older versions move to archive/releases/ and are not deleted.

## Do Not
Do not regenerate the zip.
Do not split files.
Do not modify SIA content.
Do not delete history.

## Return
1. New path
2. Archived old paths
3. active release listing
4. archive listing
5. File Registry / CHANGELOG / PATCH_LOG summary
```
