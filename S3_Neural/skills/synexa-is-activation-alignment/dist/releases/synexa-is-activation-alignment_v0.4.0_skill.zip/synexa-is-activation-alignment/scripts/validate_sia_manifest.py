#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
required = [
    "SKILL.md",
    "agents/openai.yaml",
    "VERSION",
    "CHANGELOG.md",
    "PATCH_LOG.md",
    "references/SIA_Core_Runtime_v0.4.0.md",
    "references/SIA_Strong_Base_v0.4.0.md",
    "references/SIA_Templates_v0.4.0.md",
    "references/SIA_Test_Cases_v0.4.0.md",
    "references/SIA_Migration_Notes_v0.4.0.md",
    "references/SIA_GitHub_Release_Notes_v0.4.0.md",
]
missing = [p for p in required if not (root / p).exists()]
skill_count = len(list(root.rglob("SKILL.md")))
version = (root / "VERSION").read_text(encoding="utf-8").strip() if (root / "VERSION").exists() else ""
if missing:
    print("Missing files:")
    for p in missing:
        print("-", p)
    sys.exit(1)
if skill_count != 1:
    print(f"Expected exactly one SKILL.md, found {skill_count}")
    sys.exit(1)
if version != "0.4.0":
    print(f"Expected VERSION 0.4.0, found {version}")
    sys.exit(1)
print("SIA v0.4.0 manifest OK")
