# CHANGELOG

## v0.4.0

- Rebuilt SIA as Strong Base, Light Launch.
- Fused lessons from v0.1 operational pilot, v0.2 governance base, and v0.3 minimal runtime.
- Made light launch the default user experience.
- Preserved full base as references instead of default output.
- Added selective invocation, direct production, external agent boundaries, and quality gate.
- Marked old cross-workspace routing logic as superseded.
- Added GitHub release/archive notes.

## v0.2.0

- Built comprehensive governance protocol base.
- Added roles, domains, Skill layers, assets, tests, and migration notes.
- Later judged too heavy for day-to-day launch behavior.

## v0.1.0

- Initial operational pilot.
