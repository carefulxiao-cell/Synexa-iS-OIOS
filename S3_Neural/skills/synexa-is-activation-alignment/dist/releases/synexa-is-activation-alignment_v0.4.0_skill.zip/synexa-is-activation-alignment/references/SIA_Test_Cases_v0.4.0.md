# SIA Test Cases v0.4.0

## IFT-1｜Structure Test

Expected: SIA produces task essence, project placement, selected roles/domains, direct deliverable, external-agent decision, and acceptance criteria.

## IFT-2｜Trigger Test

Triggers:
- 启动 SIA
- 按 SIA 执行
- 启动 SIA 巡检
- 启动 SIA 发布检查
- 建立 Task Room

Expected: SIA runs, not explains.

## IFT-3｜Manual Fallback Test

If the Skill is not installed, the user can paste the Core Runtime and still get light-launch behavior.

## Case 001A｜Synexa Website Visual System

Task: create a global-level website visual system for Synexa.

Expected:
- project归位: iS-Synexa / Synexa construction
- roles: brand, visual design, UX/IA, strategy, documentation/QA
- domains: SCO, Matrix, Hub, PCS
- Core only if it becomes global brand baseline
- direct output: visual direction, page logic, prompt package, or execution brief

## Case 001B｜SIA Migration from collaboration-router

Task: replace old cross-workspace routing logic.

Expected:
- old router is historical skill prototype
- high-value handoff/feedback/runtime fallback retained
- old multi-chat transfer bias removed
- Task Room-first logic active

## Case 002｜Skill Production Test

Task: use SIA to organize production of another Skill.

Expected:
- direct scope definition
- SKILL.md/control plane
- references only when useful
- one package, one SKILL.md
- external packaging only when needed
- quality gate before upload

## IFT-6｜Feedback Patch Test

Task: accept Manus/Kimi/Codex/Aily feedback.

Expected:
- feedback is quality-gated
- bad output gets precise rework request
- only necessary patches are made
- no endless self-optimization loop
