---
name: synexa-is-activation-alignment
description: Use this skill when the user says or implies “启动 SIA”, “按 SIA 执行”, “SIA 巡检”, “SIA 发布检查”, “建立 Task Room”, “这个任务怎么调用团队/Manus/Kimi/Codex/Aily”, or asks to quickly organize a complex Synexa iS task. It activates high-quality task work through strong-base, light-launch principles: quick judgment, project归位, selective role/domain invocation, direct production, clear external execution packages, and quality gates. Do not use for simple rewriting, translation, one-off summaries, or simple factual answers.
---

# Synexa iS Activation & Alignment｜SIA v0.4.0

## Runtime Principle

SIA means **Strong Base, Light Launch**.

Use SIA to start high-quality work quickly. Do not explain the whole mechanism unless the user asks. The user should experience speed, clarity, and useful output; the strong base stays available in references.

Core rule:

> Strong base. Light launch. Selective invocation. Direct production. Strict quality gate.

## When SIA Triggers

Trigger when the user asks to:
- 启动 SIA / 按 SIA 执行
- 建立 Task Room / 组织专项任务
- 判断任务应放在哪个项目或对话框
- 调用 SCO / Matrix / Hub / Lab / PCS / Core
- 生成 Manus / Kimi / Codex / Aily 任务包
- 做 Skill / SOP / GitHub / 项目包 / 视觉系统 / 官网方案等可沉淀资产
- 做 SIA 巡检或发布检查

Do **not** trigger for simple rewriting, translation, ordinary summaries, one-off factual answers, or local text edits that can be directly answered.

## Default Output: Light Launch

When the user says “启动 SIA”, output only what is needed and enter production immediately:

1. **任务本质**：one sentence.
2. **主责归位**：project / Task Room / current conversation.
3. **本轮目标**：what this round will produce.
4. **必要角色**：only required roles, usually 2–5.
5. **必要能力域**：only required domains.
6. **直接产出**：produce useful work now, not just a plan.
7. **外部执行体判断**：Manus / Kimi / Codex / Aily only if truly needed.
8. **验收标准**：how to know the result is usable.

Never list the full role system by default. Never turn SIA itself into the task unless the user asks to improve SIA.

## Invocation Logic

### 1. Light tasks
Answer directly. Do not activate SIA.

### 2. Medium tasks
Use SIA-Lite:
- task essence
- project归位
- 1–3 roles
- 1–3 capability domains
- next concrete output
- whether an external agent is needed

### 3. Complex tasks
Create a Task Room in the current conversation when possible:
- Mission Brief
- selected Expert Pod
- selected Professional Pod
- capability domains
- direct deliverables
- external task package only if files, code, GitHub, zip, long-text review, or Feishu field intake are needed

## Capability Domains

Use domains as callable views, not as mandatory separate conversations.

- **iS-SCO**: strategy, risk, reverse validation, N-Grid, EKB decision support.
- **iS-Matrix**: structured production, SOP, templates, Skill source, prompt assets.
- **iS-Hub**: external cases, tools, industry scanning, best practices.
- **iS-Lab**: concept testing, minimum validation, early experiment.
- **PCS**: project execution, asset destination, implementation rhythm.
- **iS-Core**: only global baseline, project归位, major resources, priority conflicts, organization rule changes, external commitments.

## Role Invocation

Roles are a pool, not a fixed cast.

Select only roles needed for the task. Examples:
- Strategy Expert
- Brand Expert
- Product Expert
- Technical Expert
- Data Expert
- Legal/Risk Expert
- Visual Design Expert
- UX/IA Expert
- Project Manager
- Documentation Engineer
- QA Officer
- Version Manager
- Repository Manager
- Test Lead
- Prompt Engineer

Default: use 2–5 expert/professional roles. Do not overload the user.

## External Agent Boundaries

### Manus
Use only for file landing, repository upload, directory moves, release/archive paths, zip handling, File Registry, and return feedback. Do not ask Manus for vague strategy.

### Kimi
Use for long-text review, consistency checks, old/new comparison, omissions, conflicts, and patch suggestions. Do not ask Kimi to rewrite everything unless explicitly requested.

### Codex / Claude Code / Kimi Claw
Use for code changes, repository engineering, scripts, tests, automation, frontend/backend implementation. Do not use for brand strategy or governance thinking.

### Aily
Use for Feishu field intake: chat summaries, meeting notes, task extraction, field feedback, and Task Room input packages. Aily is not global control.

## External Task Package Template

When an external agent is needed, provide a concise package:

```markdown
# Task Package

## Task Name

## Executor
Manus / Kimi / Codex / Aily

## Goal
One clear goal.

## Inputs
Explicit files/text/paths. Do not guess missing input.

## Output
Exact file/text/result required.

## Quality Standard
What counts as good enough.

## Forbidden Actions
What must not be done.

## Pause Conditions
When to stop and ask back.

## Return Format
1. What was done
2. Where the output is
3. Problems found
4. Whether it can move to the next step
```

## Quality Gate

Before accepting any external result, check:
1. Did it meet the stated goal?
2. Did it drift or replace the concept?
3. Is the output usable now?
4. Is quality high enough for the next step?
5. Are file paths/version/status clear?
6. Does it need rework?

If not good enough, produce a precise rework request.

## Deeper References

Load references only when needed:
- `references/SIA_Core_Runtime_v0.4.0.md` for runtime philosophy and operating logic.
- `references/SIA_Strong_Base_v0.4.0.md` for complete base structure.
- `references/SIA_Templates_v0.4.0.md` for task packages and quality gate templates.
- `references/SIA_Test_Cases_v0.4.0.md` for IFT and case testing.
- `references/SIA_Migration_Notes_v0.4.0.md` for relationship with v0.1/v0.2/v0.3 and old router.
- `references/SIA_GitHub_Release_Notes_v0.4.0.md` for GitHub upload/archive rules.
